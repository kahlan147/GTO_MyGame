Arthur Cousseau, 2017
https://www.linkedin.com/in/arthurcousseau/
Please share this if you enjoy it! :)


HOW TO USE:

- Right click in your Project or Hierarchy window, or go to the Assets menu tab.
- Go to Create -> Eldoir -> Piece
- A new file named "Piece_Data" is created.
- Feel free to change the grid size! :)
